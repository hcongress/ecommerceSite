<template>
<v-card
    max-width="90%"
    class="mx-auto mb-5"
    style="margin-top: 5%;"
    elevation="3" >
    <v-card dark elevation= "5" color="#7300ff" class="mb-1">
    <v-list-item>
      <v-list-item-avatar color="grey">
        <v-img src="https://images.unsplash.com/photo-1503249023995-51b0f3778ccf?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=911&q=80">
        </v-img>
      </v-list-item-avatar>
      <v-list-item-content>
        <v-list-item-title class="headline">The Art of Racing in the Rain</v-list-item-title>
        <v-list-item-subtitle>by Lorem Ipsem</v-list-item-subtitle>
      </v-list-item-content>
    </v-list-item>
    </v-card>

  <img id="change" src="https://www.foxmovies.com/s3/dev-temp/en-US/__5d82759da2b3e.jpg" style="max-height: 20%; width: 100%;"/>
      <v-btn  class="pa-0 ma-1" @click="onClick1" min-height="50" min-width="50" max-height="100" max-width="100">
          <v-img id ="1" :src="items[0].src" min-height="50" min-width="50" max-height="100" max-width="100"/>
    </v-btn>
    <v-btn class="pa-0 ma-1" @click="onClick2" min-height="50" min-width="50" max-height="100" max-width="100">
          <v-img  id ="2" :src="items[1].src" min-height="50" min-width="50" max-height="100" max-width="100"/>
    </v-btn>
    <v-btn class="pa-0 ma-1" @click="onClick3" min-height="50" min-width="50" max-height="100" max-width="100">
          <v-img id ="3" :src="items[2].src" min-height="50" min-width="50" max-height="100" max-width="100"/>
    </v-btn>
    <v-btn class="pa-0 ma-1" @click="onClick4" min-height="50" min-width="50" max-height="100" max-width="100">
          <v-img id ="4" :src="items[3].src" min-height="50" min-width="50" max-height="100" max-width="100"/>
    </v-btn>
    <v-card-text>
     <v-row
        align="center"
        class="mx-0"
      >
        <v-rating
          :value="4.5"
          color="amber"
          dense
          half-increments
          readonly
          size="24"
        ></v-rating>
        <div class="grey--text ml-4">4.5 (413)</div>
        <v-card-subtitle>$12.99</v-card-subtitle>
      </v-row>
      <v-card-title>Description</v-card-title>
      <div class="my-4 subtitle-1 black--text ma-5">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
        Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.
        Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.
        Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?
      </div>
      <v-card dark color="#7300ff" elevation="3 mb-1">
        <v-card-title class="justify-center">Reviews</v-card-title>
        </v-card>
        <v-card>
              <v-row v-for="(review, n) in reviews" :key="n" class="pa-4">
                <v-card-title>{{review.title}}</v-card-title>
                <v-card-text>
                  <div class="subtitle-1 grey--text">by: {{review.name}}</div>
                <div class="pb-4">{{review.text}}</div>
                <v-divider></v-divider>
                </v-card-text>
              </v-row>
          </v-card>
                  <v-card dark color="#7300ff" elevation="6">
        <v-card-title class="justify-center ma-4">Customers who viewed this item also viewed</v-card-title>
        </v-card>
    <v-row align="center" justify="center">
      <v-card
           align="start"
          justify="space-around"
          :elevation= "3"
            v-for="(info,n) in books"
            :key="n"
            class="ma-4 mx-6"
            max-width="350"
            min-width="300"
            outlined
            tile
          >
    <v-img
      class="white--text align-end"
      height="200px"
      :src= "info.src"
    >
      <v-card-title>{{info.title}}</v-card-title>
    </v-img>

    <v-card-subtitle class="pb-0">{{info.price}}</v-card-subtitle>
    <v-card-text class="text--primary">
      <div>{{info.description}}</div>
    </v-card-text>

    <v-card-actions>
      <v-btn
        color="indigo"
        text
        to="/products"
      >
        Check out
      </v-btn>
    </v-card-actions>
    </v-card>
    </v-row>
    </v-card-text>

  </v-card>
</template>
<script>
export default {
  data: () => ({
    loading: false,
    selection: 1,
    items: [
      {
        src: 'http://juliesaysso.com/wp-content/uploads/2019/07/RacingRain-800x450.jpg'
      },
      {
        src: 'https://media3.s-nbcnews.com/j/newscms/2019_32/2966756/190809-milo-ventimiglia-art-of-racing-in-the-rain-ac-752p_95ce0bebcdeab96016edb4a2ceef27bc.fit-2000w.jpg'
      },
      {
        src: 'https://www.foxmovies.com/s3/dev-temp/en-US/__5d82759da2b3e.jpg'
      },
      {
        src: 'https://www.eyecinema.ie/thumb.php?src=/images/films/the-art-of-racing-in-the-rain-backdrop-75.jpg&w=765&h=350&zc=1'
      }
    ],
    reviews: [
      {
        name: 'Hunter',
        title: 'Fantastic watch!',
        text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.Nemo enim ipsam voluptatem quia voluptas sit aspernatur'
      },
      {
        name: 'Tommy',
        title: 'Hunter would not stop talking',
        text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.Nemo enim ipsam voluptatem quia voluptas sit aspernatur'
      },
      {
        name: 'Hunter',
        title: 'Stop  Tommy',
        text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.Nemo enim ipsam voluptatem quia voluptas sit aspernatur'
      }
    ],
    books: [
      { title: 'How to do Taxes',
        price: '$12.99',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
        src: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80' },
      { title: 'Explosion of the Societies',
        price: '$12.99',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
        src: 'https://images.unsplash.com/photo-1467864858819-8737df8215b6?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80' },
      { title: 'Great Advice for Great People',
        price: '$12.99',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
        src: 'https://images.unsplash.com/photo-1491438590914-bc09fcaaf77a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80' }
    ]

  }),

  methods: {
    onClick1 () {
      document.getElementById('change').src = 'http://juliesaysso.com/wp-content/uploads/2019/07/RacingRain-800x450.jpg'
    },
    onClick2 () {
      document.getElementById('change').src = 'https://media3.s-nbcnews.com/j/newscms/2019_32/2966756/190809-milo-ventimiglia-art-of-racing-in-the-rain-ac-752p_95ce0bebcdeab96016edb4a2ceef27bc.fit-2000w.jpg'
    },
    onClick3 () {
      document.getElementById('change').src = 'https://www.foxmovies.com/s3/dev-temp/en-US/__5d82759da2b3e.jpg'
    },
    onClick4 () {
      document.getElementById('change').src = 'https://www.eyecinema.ie/thumb.php?src=/images/films/the-art-of-racing-in-the-rain-backdrop-75.jpg&w=765&h=350&zc=1'
    }

  }
}
</script>
