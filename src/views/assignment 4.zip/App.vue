<template>
    <v-app>
    <v-app-bar
      color="#fcb69f"
      dark
      src="./assets/books.jpeg"
      scroll-target="#scrolling-techniques-1"
    >
      <template v-slot:img="{ props }">
        <v-img
          v-bind="props"
          gradient="to top right, rgba(22,11,255,.5), rgba(199,94,255,.8)"
        ></v-img>
      </template>
      <v-menu top :offset-x="offset">
            <template v-slot:activator="{ on }">
              <v-btn
                dark
                icon
                v-on="on"
              >
                <v-app-bar-nav-icon></v-app-bar-nav-icon>
              </v-btn>
            </template>

            <v-list class="blue lighten-3">
              <v-list-item
                v-for="(item, i) in items"
                :key="i"
              >
                <v-list-item-title>
                  <v-btn to="/category" dark class="indigo darken-4">{{ item.title }}</v-btn>
                  </v-list-item-title>
              </v-list-item>
            </v-list>
          </v-menu>
      <v-toolbar-title class="display-1 font-weight-black">
        <router-link to="/" class= "white--text" style="text-decoration: none;">Congels &nbsp;</router-link>
          </v-toolbar-title>
          <v-toolbar-title class="display-1 font-weight-regular blue-grey--text">
        <router-link to="/" style="text-decoration: none; color: #90CAF9">Book Store</router-link>
          </v-toolbar-title>

      <v-spacer></v-spacer>
      <v-btn text>Log In</v-btn>
        <v-btn text>Sign Up</v-btn>

      <v-btn icon>
        <v-icon>mdi-shopping</v-icon>
      </v-btn>
    </v-app-bar>
    <v-content class="content">
    <router-view/>
    </v-content>
      <v-footer padless class="deep-purple accent-2" dark>

    <v-col
      class="text-center"
      cols="12"
    >
      {{ new Date().getFullYear() }} — <strong>Created by: Hunter Congress and Thomas Engels</strong>
    </v-col>
  </v-footer>
    </v-app>

</template>

<script>

export default {
  name: 'App',
  data: () => ({
    items: [
      { title: 'Action' },
      { title: 'Drama' },
      { title: 'Fiction' },
      { title: 'Adventure' },
      { title: 'Historical' },
      { title: 'Science Fiction' },
      { title: 'Nonfiction' },
      { title: 'Romance' },
      { title: 'Science' }
    ]
  })
}
</script>
